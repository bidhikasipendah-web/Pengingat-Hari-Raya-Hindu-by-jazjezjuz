PENGINGAT HARI RAYA HINDU BALI — V2

Cara memakai:
1. Ekstrak ZIP.
2. Buka index.html untuk mencoba aplikasinya.
3. Untuk instalasi seperti aplikasi HP, host folder ini melalui HTTPS (misalnya GitHub Pages/Netlify), lalu buka dari Chrome Android dan pilih "Tambahkan ke layar utama".
4. Notifikasi web memerlukan izin browser dan HTTPS. Versi ini sudah menyiapkan PWA; untuk alarm yang tetap berjalan kuat saat aplikasi ditutup total, langkah berikutnya adalah membungkusnya menjadi APK native.

Catatan:
- Daftar tanggal di file ini adalah data contoh 2026 dan perlu diverifikasi dengan kalender resmi/rujukan kalender Bali sebelum dipakai sebagai kalender upacara resmi.
- Fitur pengingat pribadi tersimpan di perangkat melalui localStorage.
